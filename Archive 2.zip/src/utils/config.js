const path = require("path");

const UPLOAD_DIR = path.join(__dirname, "../../hidden_folder_xyz");

module.exports = {
  UPLOAD_DIR,
};
